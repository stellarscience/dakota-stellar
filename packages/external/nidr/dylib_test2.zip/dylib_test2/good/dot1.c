#include "nidr.h"

/** 9 distinct keywords (plus 5 aliases) **/

static KeyWordx
	kw_1[2] = {
		{{"maximize",0x20008,0,1,1},14,17,"N_mdm(lit,minMaxType_maximize)"},
		{{"minimize",0x20008,0,1,1},13,15,"N_mdm(lit,minMaxType_minimize)"}
		},
	kw_2[11] = {
		{{"bfgs",0x20008,0,1,1},6,7,"N_mdm(lit,methodName_dot_bfgs)"},
		{{"dot_bfgs",0x20000,0,1,1,0,0.,0.,-1},7,6,"N_mdm(lit,methodName_dot_bfgs)"},
		{{"dot_frcg",0x20000,0,1,1,0,0.,0.,4},3,2,"N_mdm(lit,methodName_dot_frcg)"},
		{{"dot_mmfd",0x20000,0,1,1,0,0.,0.,4},5,4,"N_mdm(lit,methodName_dot_mmfd)"},
		{{"dot_slp",0x20000,0,1,1,0,0.,0.,5},9,8,"N_mdm(lit,methodName_dot_slp)"},
		{{"dot_sqp",0x20000,0,1,1,0,0.,0.,5},11,10,"N_mdm(lit,methodName_dot_sqp)"},
		{{"frcg",0x20008,0,1,1},2,3,"N_mdm(lit,methodName_dot_frcg)"},
		{{"mmfd",0x20008,0,1,1},4,5,"N_mdm(lit,methodName_dot_mmfd)"},
		{{"optimization_type",0x20008,2,2,0,(KeyWord*)kw_1},12,13},
		{{"slp",0x20008,0,1,1},8,9,"N_mdm(lit,methodName_dot_slp)"},
		{{"sqp",0x20008,0,1,1},10,11,"N_mdm(lit,methodName_dot_sqp)"}
		},
	kw_3[1] = {
		{{"dot",0x20008,11,1,1,(KeyWord*)kw_2},1,1,"dot_start"}
		};

#ifdef __cplusplus
extern "C" {
KeyWord *keyword_add(void);
}
#endif

 KeyWord*
keyword_add(void) {
	return &kw_3[0].kw;
	}
