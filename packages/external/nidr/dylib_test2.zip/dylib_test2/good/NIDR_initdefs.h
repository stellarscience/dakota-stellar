#define fdGradStepDflt 0.001
