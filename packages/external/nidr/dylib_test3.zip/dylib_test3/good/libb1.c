#include "nidr.h"

/** 4 distinct keywords (plus 0 aliases) **/

static KeyWordx
	kw_1[3] = {
		{{"b1op1",0x20008,0,1},2,3},
		{{"b1req1",0x20008,0,2,1},3,5},
		{{"b1req2",0x20008,0,3,2},4,7}
		},
	kw_2[1] = {
		{{"reqb1",0x20008,3,1,1,(KeyWord*)kw_1},1,1}
		};

#ifdef __cplusplus
extern "C" {
KeyWord *keyword_add(void);
}
#endif

 KeyWord*
keyword_add(void) {
	return &kw_2[0].kw;
	}
